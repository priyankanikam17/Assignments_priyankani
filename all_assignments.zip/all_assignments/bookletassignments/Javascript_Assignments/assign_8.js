function charSearch(){
    var index;
    var name = new String("administrator");
    var companyName = new String("Cybage Software pvt. ltd. is popularly known as ");
    var companyNamecapital = new String("CYBAGE SOFTWARE PVT,LTD");
    var companyNamesmall = new String("cybage software pvt. ltd.");
    var input = document.getElementById('inputchar').value;
    index = name.search(input);
    
    if(index != -1)
    {
        document.writeln("Character "+input+" is present at "+index+" index.");
        document.write("\n");
        document.writeln(companyName+companyName.substring(0,14));
        document.write("\n");
        document.write(companyNamecapital.toLowerCase());
        document.write("\n");
        document.write(companyNamesmall.toUpperCase());
        
    }
    else{
        document.writeln("Character is not present in the "+name+" String");
    }
}