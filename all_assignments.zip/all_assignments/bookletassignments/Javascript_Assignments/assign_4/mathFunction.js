var result;

function addNumbers(headParam,bodyParam)
{
   result= headParam + bodyParam;
    return result;
    
}
