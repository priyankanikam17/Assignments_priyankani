function valthisform(){
    var chkd = document.f1.ch.checked || document.f1.ch.checked||document.f1.ch.checked|| document.f1.ch.checked
   
    if (chkd == true){
   
    } else {
       alert ("please check a checkbox");
    }
   
   }