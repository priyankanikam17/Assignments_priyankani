var myDate = new Date();
function greetuser()
{
    
    
    //document.write(myDate);
    var hrs = myDate.getHours();
    
    var greet;

    if (hrs < 12)
    {
        greet = 'Good Morning..!!!';
        return greet;
    }
    else if (hrs >= 12 && hrs <= 17)
    {
        greet = 'Good Afternoon..!!!';
        return greet;
    }
    else if (hrs >= 17 && hrs <= 24)
    {    
        greet = 'Good Evening..!!!';
        return greet;
    }
    
}