function sayhello()
{
    document.write("Hello from javascript");
}