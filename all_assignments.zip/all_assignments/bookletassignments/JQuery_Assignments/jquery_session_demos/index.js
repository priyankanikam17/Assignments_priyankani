$("document").ready(
    ()=>{
        alert("Jquery is loaded!!!")
    }
);