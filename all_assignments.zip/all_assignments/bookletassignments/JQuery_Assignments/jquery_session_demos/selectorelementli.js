
$("document").ready(
    ()=>{
    var li3eq=$('li').eq(2);
    console.log(li3eq);
    
    var li3get=$('li').get(2);
    console.log(li3get);
    
    var li3child=$('li:nth-child(3)');
    console.log(li3child);
    
    
    
}
);
