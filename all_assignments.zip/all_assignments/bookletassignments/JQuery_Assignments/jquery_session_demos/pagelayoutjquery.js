$("document").ready(
    ()=>{

        //for header
        $('#header').width('1191px');
        $('#header').height('100px');
        $('#header').css({"border-color": "black", 
             "border-weight":"1px", 
             "border-style":"solid"});
        
        $('#leftpane').width('391px');
        $('#leftpane').height('500px');
        $('#leftpane').css({"border-color": "black", 
              "border-weight":"1px", 
              "border-style":"solid",
              //"top":"115px",
              "position":"absolute"
            });

            $('#centerpane').width('399px');
        $('#centerpane').height('500px');
        $('#centerpane').css({"border-color": "black", 
              "border-weight":"1px", 
              "border-style":"solid",
              "left":"400px",
              //"top":"115px",
            "position":"absolute"});

              $('#rightpane').width('400px');
        $('#rightpane').height('500px');
        $('#rightpane').css({"border-color": "black", 
              "border-weight":"1px", 
              "border-style":"solid",
              "left":"800px",
              //"top":"115px",
              "position":"absolute"});
                  
              $('#footer').width('1191px');
              $('#footer').height('100px');
              $('#footer').css({"border-color": "black", 
                   "border-weight":"1px", 
                   "border-style":"solid",
                "top":"614px",
                "position":"absolute"});
    }
    );