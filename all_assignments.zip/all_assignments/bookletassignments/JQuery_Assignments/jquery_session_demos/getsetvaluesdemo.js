$("document").ready(
    ()=>{

        
    }
    );