$("document").ready(
    ()=>{
  var getalldivs = $('div');
  console.log(getalldivs);

  var getalldivswithid = $('#divid');
  console.log(getalldivswithid);

  var getalldivswithclass = $('.myStyle');
  console.log(getalldivswithclass);

  var getalldivsAndClass = $('.mySyle.MyHeader');
  console.log(getalldivsAndClass);

  var firstdiv = $('div:first');
  console.log(firstdiv);

  var lastdiv = $('div:last');
  console.log(lastdiv);

  var evendiv = $('div:even');
  console.log(evendiv);        
    }
);