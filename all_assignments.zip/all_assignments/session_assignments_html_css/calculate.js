function calculate()
{
    var person = prompt("Please enter the price:");
    
    
}