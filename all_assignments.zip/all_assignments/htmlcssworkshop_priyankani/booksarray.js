var books = ["Wings Of Fire","Partner"];
var input1,input2;
// document.getElementById("list").innerHTML = books;


function navaddBook(){
    var x = document.getElementById("divadd");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";

}
}

function navremoveBook(){
    var y = document.getElementById("divremove");
    if (y.style.display === "block") {
        y.style.display = "none";
    } else {
        y.style.display = "block";

}
}

function navshowBook(){
    var z = document.getElementById("divshow");
    if (z.style.display === "block") {
        z.style.display = "none";
    } else {
        z.style.display = "block";

}
}
function addBook() {

     input1 = document.getElementById("bk");
    
        books.push(input1.value);
        document.getElementById("list").innerHTML = books;

      }

    
  


function removeBook() {
     input2 = document.getElementById("bkr");
    
  books.pop(input2.value);
  document.getElementById("list1").innerHTML = books;
   

}

function showBook() {
    // var input = document.getElementById("bkr");
    
//   books.pop(input.value);
  document.getElementById("list2").innerHTML = books;
    

}
