// $(document).ready(function(){
//     //$("h2").css({ "background": "#ccc", "color": "white","padding": "30px"});
//     $("h2").css("background","#ccc");
//     $("h2").css("text-align","center");
//     $("h2").html("Cybage");
// });

$(document).ready(function(){
    $("h2").css({ "background": "#ccc", "color": "black","padding": "30px"});
    $("h2").css("text-align","center");
    $("h2").html("Cybage");

    $("#aside1").css({"float":"left","width":"30%","height":"300px","backround":"#ccc","padding":"20px"});
    $("nav").html("Section");
    
    $("article").css({"float":"left","width":"70%","height":"300px","backround":"#f1f1f1","padding":"20px"});
    $("article").html("Section");

    $("section","after").css({"content":"","display":"table","clear":"both"});
//     width: 30%;
//   padding-left: 15px;
//   margin-left: 15px;
//   float: right;
//   font-style: italic;
//   background-color: lightgray;
    
    $("footer").css({"backround":"#ccc","padding":"10px","text-align":"center","color":"black","clear":"both"});
    $("footer").html("footer");
    
    
  });